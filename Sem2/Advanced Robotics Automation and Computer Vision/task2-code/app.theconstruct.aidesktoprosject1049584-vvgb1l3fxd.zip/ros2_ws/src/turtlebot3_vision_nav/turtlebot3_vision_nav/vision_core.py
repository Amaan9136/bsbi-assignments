from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np


LOWER_RED_1 = np.array([0, 120, 70])
UPPER_RED_1 = np.array([10, 255, 255])

LOWER_RED_2 = np.array([170, 120, 70])
UPPER_RED_2 = np.array([180, 255, 255])

MIN_CONTOUR_AREA = 500


@dataclass
class DetectionResult:
    offset: float
    visible: bool
    centroid: Optional[Tuple[int, int]]
    contour_area: float
    debug_frame: np.ndarray


def build_red_mask(hsv_frame: np.ndarray) -> np.ndarray:

    mask1 = cv2.inRange(
        hsv_frame,
        LOWER_RED_1,
        UPPER_RED_1
    )

    mask2 = cv2.inRange(
        hsv_frame,
        LOWER_RED_2,
        UPPER_RED_2
    )

    mask = cv2.bitwise_or(mask1, mask2)

    kernel = np.ones((5, 5), np.uint8)

    mask = cv2.morphologyEx(
        mask,
        cv2.MORPH_OPEN,
        kernel
    )

    mask = cv2.morphologyEx(
        mask,
        cv2.MORPH_CLOSE,
        kernel
    )

    return mask


def detect_marker(
    frame_bgr: np.ndarray,
    min_area: float = MIN_CONTOUR_AREA
) -> DetectionResult:

    height, width = frame_bgr.shape[:2]

    frame_center_x = width / 2.0

    hsv = cv2.cvtColor(
        frame_bgr,
        cv2.COLOR_BGR2HSV
    )

    mask = build_red_mask(hsv)

    contours, _ = cv2.findContours(
        mask,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    debug_frame = frame_bgr.copy()

    offset = 0.0
    visible = False
    centroid = None
    area = 0.0

    if contours:

        largest_contour = max(
            contours,
            key=cv2.contourArea
        )

        area = cv2.contourArea(
            largest_contour
        )

        if area >= min_area:

            moments = cv2.moments(
                largest_contour
            )

            if moments["m00"] != 0:

                centroid_x = (
                    moments["m10"] /
                    moments["m00"]
                )

                centroid_y = (
                    moments["m01"] /
                    moments["m00"]
                )

                centroid = (
                    int(centroid_x),
                    int(centroid_y)
                )

                offset = (
                    centroid_x -
                    frame_center_x
                ) / frame_center_x

                visible = True

                cv2.drawContours(
                    debug_frame,
                    [largest_contour],
                    -1,
                    (0, 255, 0),
                    2
                )

                cv2.circle(
                    debug_frame,
                    centroid,
                    6,
                    (255, 0, 0),
                    -1
                )

    cv2.line(
        debug_frame,
        (width // 2, 0),
        (width // 2, height),
        (0, 255, 255),
        1
    )

    cv2.putText(
        debug_frame,
        f"visible={visible} offset={offset:.2f}",
        (10, 25),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (255, 255, 255),
        2
    )

    return DetectionResult(
        offset=offset,
        visible=visible,
        centroid=centroid,
        contour_area=area,
        debug_frame=debug_frame
    )


if __name__ == "__main__":

    import sys

    frame = np.zeros(
        (480, 640, 3),
        dtype=np.uint8
    )

    cv2.rectangle(
        frame,
        (400, 200),
        (460, 260),
        (0, 0, 255),
        -1
    )

    result = detect_marker(frame)

    print(
        f"visible={result.visible} "
        f"offset={result.offset:.3f} "
        f"centroid={result.centroid}"
    )

    if not result.visible:
        print(
            "Smoke test FAILED: "
            "expected marker was not detected.",
            file=sys.stderr
        )
        sys.exit(1)

    print("Smoke test passed.")
